const { getNearbyPlaces,getNearByPlacesFromInternally } = require('../utils/googleMaps');
const axios = require('axios');

exports.fetchNearByStation = async (lat, lng, type, radius) => {
  const location = `${lat},${lng}`;
  const stations = await getNearbyPlaces(location, type, radius);
  return stations.map(station => ({
    name: station.name,
    location: station.geometry.location,
    place_id: station.place_id
  }));
};

exports.fetchInternalApi = async (lat, lng, type) => {
  const location = `lat=${lat}&lng=${lng}`;
  const stations = await getNearByPlacesFromInternally(location, type);
  return stations
};

// module.exports = { fetchNearByStation };
