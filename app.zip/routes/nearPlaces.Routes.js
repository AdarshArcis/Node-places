const express = require('express');
const { getNearByMetroStations,
    getNearByBusStops,
    getPlacesGroupOfData,
    getNearByRailwaySations,
    getNearByHospitals,
    getNearBySchools,
    getNearByMovieTheaters,
    getNearByShoppingMalls,
    getNearBySuperMarkets
} = require('../controllers/nearPlaces.Controller');
const cacheMiddleware = require('../middlewares/cacheMiddleware');
const router = express.Router();

router.get('/get-nearby/metro-stations', cacheMiddleware, getNearByMetroStations);
router.get('/get-nearby/bus-stops', cacheMiddleware, getNearByBusStops);
router.get('/get-nearby/railway-station', cacheMiddleware, getNearByRailwaySations);
router.get('/get-nearby/hospitals', cacheMiddleware, getNearByHospitals);
router.get('/get-nearby/schools', cacheMiddleware, getNearBySchools);
router.get('/get-nearby/movie-theaters', cacheMiddleware, getNearByMovieTheaters);
router.get('/get-nearby/shopping-malls', cacheMiddleware, getNearByShoppingMalls);
router.get('/get-nearby/super-markets', cacheMiddleware, getNearBySuperMarkets);
router.get('/get-nearby/places-groups', cacheMiddleware, getPlacesGroupOfData);

module.exports = router;
