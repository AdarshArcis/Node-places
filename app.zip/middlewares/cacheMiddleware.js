const cache = require('../config/cacheConfig');

const cacheMiddleware = (req, res, next)=>{
    const key = req.originalUrl;
    const cacheResponse = cache.get(key);
    if (cacheResponse) {
        return res.status(200).json(cacheResponse);
    }
    res.sendResponse = res.json;
    res.json = (body) =>{
        cache.set(key, body);
        res.sendResponse(body);
    }

    next();
}

module.exports = cacheMiddleware;