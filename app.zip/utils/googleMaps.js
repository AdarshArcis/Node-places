const axios = require('axios');
const { googleApiKey } = require('../config/config');

exports.getNearbyPlaces = async (location, type="subway_station", radius = 5000) => {
  const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${location}&radius=${radius}&type=${type}&key=${googleApiKey}`;
  const response = await axios.get(url);
  return response.data.results;
};

exports.getNearByPlacesFromInternally = async (location) => {
  const endpoints = [
    `http://localhost:3000/api/v1/get-nearby/metro-stations?${location}`,
    `http://localhost:3000/api/v1/get-nearby/bus-stops?${location}`,
    `http://localhost:3000/api/v1/get-nearby/railway-station?${location}`,
    `http://localhost:3000/api/v1/get-nearby/hospitals?${location}`,
    `http://localhost:3000/api/v1/get-nearby/schools?${location}`,
    `http://localhost:3000/api/v1/get-nearby/movie-theaters?${location}`,
    `http://localhost:3000/api/v1/get-nearby/shopping-malls?${location}`,
    `http://localhost:3000/api/v1/get-nearby/super-markets?${location}`,
  ];

  try {
    const responses = await Promise.all(endpoints.map(url => axios.get(url).catch(error => ({ error }))));
    const results = responses.map(response => {
      if (response.error) {
        console.error(`Error fetching data from ${response.error.config.url}: ${response.error.message}`);
        return { data: [] }; // Return an empty array in case of error
      }
      return response.data;
    });

    let obj = {
      transit: {
        metroStations: results[0].data,
        busStops: results[1].data,
        railwayStations: results[2].data,
      },
      essentials: {
        hospitals: results[3].data,
        schools: results[4].data,
      },
      utility: {
        movieTheaters: results[5].data,
        shoppingMalls: results[6].data,
        superMarkets: results[7].data,
      }
    };
    return obj;
  } catch (error) {
    console.error('An unexpected error occurred:', error.message);
    throw new Error('Failed to fetch nearby places');
  }
};


// module.exports = { getNearbyPlaces };
