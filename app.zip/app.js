const express = require('express');
const nearPlacesRoutes = require('./routes/nearPlaces.Routes');
const { port } = require('./config/config');
const app = express();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.use('/api/v1', nearPlacesRoutes);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
