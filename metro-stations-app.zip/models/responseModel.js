// models/responseModel.js
class ResponseModel {
    constructor(data, success, httpStatusCode, message, errorFields, pageNumber, pageSize, totalPages, totalRecord) {
        this.data = data;
        this.success = success;
        this.httpStatusCode = httpStatusCode;
        this.message = message;
        this.errorFields = errorFields;
        this.pageNumber = pageNumber;
        this.pageSize = pageSize;
        this.totalPages = totalPages;
        this.totalRecord = totalRecord;
    }
}

module.exports = ResponseModel;
