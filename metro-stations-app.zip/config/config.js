require('dotenv').config();

module.exports = {
  googleApiKey: process.env.GOOGLE_API_KEY,
  port: process.env.PORT || 3000,
  API_URL: process.env.API_URL + process.env.PORT
};
