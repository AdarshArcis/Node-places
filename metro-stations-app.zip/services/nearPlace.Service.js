const { getNearbyPlaces,getNearByPlacesFromInternally,getNearByPlacesFromInternallyByName } = require('../utils/googleMaps');

exports.fetchNearByStation = async (lat, lng, type, radius) => {
  const location = `${lat},${lng}`;
  const stations = await getNearbyPlaces(location, type, radius);
  return stations.slice(0, 5);
};

exports.fetchInternalApi = async (lat, lng) => {
  const location = `lat=${lat}&lng=${lng}`;
  const stations = await getNearByPlacesFromInternally(location);
  return stations
};

exports.fetchInternalApiWithPlaceName = async (placeName) => {
  const place = `placeName=${placeName}`;
  const stations = await getNearByPlacesFromInternallyByName(place);
  return stations
};

// module.exports = { fetchNearByStation };
