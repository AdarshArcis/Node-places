const express = require('express');
const { 
    getNearByMetroStations,
    getNearByBusStops,
    getNearByRailwaySations,
    getNearByHospitals,
    getNearBySchools,
    getNearByMovieTheaters,
    getNearByShoppingMalls,
    getNearBySuperMarkets,
    getNearByAirports,
    getPlacesGroupOfData,
    getPlacesGroupOfDataByName
} = require('../controllers/nearPlaces.Controller');
const cacheMiddleware = require('../middlewares/cacheMiddleware');
const router = express.Router();

router.get('/v1/get-nearby/metro-stations', cacheMiddleware, getNearByMetroStations);
router.get('/v1/get-nearby/bus-stops', cacheMiddleware, getNearByBusStops);
router.get('/v1/get-nearby/railway-station', cacheMiddleware, getNearByRailwaySations);
router.get('/v1/get-nearby/hospitals', cacheMiddleware, getNearByHospitals);
router.get('/v1/get-nearby/schools', cacheMiddleware, getNearBySchools);
router.get('/v1/get-nearby/movie-theaters', cacheMiddleware, getNearByMovieTheaters);
router.get('/v1/get-nearby/shopping-malls', cacheMiddleware, getNearByShoppingMalls);
router.get('/v1/get-nearby/super-markets', cacheMiddleware, getNearBySuperMarkets);
router.get('/v1/get-nearby/airports', cacheMiddleware, getNearByAirports);
router.get('/v1/get-nearby/places-groups', cacheMiddleware, getPlacesGroupOfData);
router.get('/v2/get-nearby/places-groups-by-name', cacheMiddleware, getPlacesGroupOfDataByName);

module.exports = router;
