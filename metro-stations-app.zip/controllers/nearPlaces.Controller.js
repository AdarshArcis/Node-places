const { fetchNearByStation, fetchInternalApi, fetchInternalApiWithPlaceName } = require('../services/nearPlace.Service');
const createResponse = require('../utils/createResponse');

// Retrieve all Near By Metro station from the API.
exports.getNearByMetroStations = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng);
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ error: 'Failed to fetch metro stations' });
  }
};

// Retrieve all Near By Bus Stops from the API.
exports.getNearByBusStops = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'transit_station');
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Bus stops' });
  }
};

// Retrieve all Near By Railway statoin from the API.
exports.getNearByRailwaySations = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'train_station', 8000);
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Railway Stations' });
  }
};

// Retrieve all Near By Hospitals from the API.
exports.getNearByHospitals = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'hospital');
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Hospitals' });
  }
};

// Retrieve all Near By Schools from the API.
exports.getNearBySchools = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'school');
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Schools' });
  }
};

// Retrieve all Near By Movie Theaters from the API.
exports.getNearByMovieTheaters = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'movie_theater');
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Movie Theaters ' });
  }
};

// Retrieve all Near By Shopping Malls from the API.
exports.getNearByShoppingMalls = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'shopping_mall');
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Shopping Malls' });
  }
};

// Retrieve all Near By Super Markets from the API.
exports.getNearBySuperMarkets = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'shopping_mall');
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch Super Markets' });
  }
};

// Retrieve all Near By airport from the API.
exports.getNearByAirports = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchNearByStation(lat, lng, 'airport', 10000);
    const response = createResponse(stations);
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch airport' });
  }
};

// Retrieve all Near By Bus Stops and metro staion  from the API.
exports.getPlacesGroupOfData = async (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: 'Latitude and longitude are required' });
  }
  try {
    const stations = await fetchInternalApi(lat, lng);
    const response = createResponse(stations);
    response.totalRecord = stations?.count;
    delete response.data.count;
    res.json(response);
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ error: 'Failed to fetch Data', message: error.message });
  }
};

// Retrieve all Near By Bus Stops and metro staion  from the API using name.
exports.getPlacesGroupOfDataByName = async (req, res) => {
  const { placeName } = req.query;
  if (!placeName) {
    return res.status(200).json({ error: 'Place name is  required' });
  }
  try {
    const stations = await fetchInternalApiWithPlaceName(placeName);
    const response = createResponse(stations);
    res.json(response.data);
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ error: 'Failed to fetch Data', message: error.message });
  }
};