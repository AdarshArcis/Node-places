const axios = require('axios');
const { googleApiKey,API_URL } = require('../config/config');

exports.getNearbyPlaces = async (location, type="subway_station", radius = 5000) => {
  const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${location}&radius=${radius}&type=${type}&key=${googleApiKey}`;
  const response = await axios.get(url);
  let placesResponse = response;
  if (placesResponse.data.status !== 'OK') {
    console.error('Error fetching nearby places:', placesResponse.data.error_message);
    return [];
  }
  const nearbyPlaces = placesResponse.data.results;
  const origins = [location]; // User's location
  // const result = await getDistanceAndTime(nearbyPlaces, origins,placesResponse)
  return formattedAddress(nearbyPlaces);
};

exports.getNearByPlacesFromInternally = async (location) => {
  const endpoints = [
    `${API_URL}/api/v1/get-nearby/metro-stations?${location}`,
    `${API_URL}/api/v1/get-nearby/bus-stops?${location}`,
    `${API_URL}/api/v1/get-nearby/railway-station?${location}`,
    `${API_URL}/api/v1/get-nearby/hospitals?${location}`,
    `${API_URL}/api/v1/get-nearby/schools?${location}`,
    `${API_URL}/api/v1/get-nearby/movie-theaters?${location}`,
    `${API_URL}/api/v1/get-nearby/shopping-malls?${location}`,
    `${API_URL}/api/v1/get-nearby/super-markets?${location}`,
  ];
  try {
    const responses = await Promise.all(endpoints.map(url => axios.get(url).catch(error => ({ error }))));
    const results = responses.map(response => {
      if (response.error) {
        console.error(`Error fetching data from ${response.error.config.url}: ${response.error.message}`);
        return { data: [] }; // Return an empty array in case of error
      }
      return response.data;
    });

    let dataCounted = results.reduce((acc, current)=>{
      return acc + current.totalRecord
    },0)
    let obj = {
      transit: {
        metroStations: results[0].data,
        busStops: results[1].data,
        railwayStations: results[2].data,
      },
      essentials: {
        hospitals: results[3].data,
        schools: results[4].data,
      },
      utility: {
        movieTheaters: results[5].data,
        shoppingMalls: results[6].data,
        superMarkets: results[7].data,
      },
      count:dataCounted
    };
    return obj;
  } catch (error) {
    console.error('An unexpected error occurred:', error.message);
    throw new Error('Failed to fetch nearby places');
  }
};

exports.getNearByPlacesFromInternallyByName = async (placeName) => {
  try {
    const response1 = await axios.get(`https://maps.googleapis.com/maps/api/geocode/json?address=${placeName}&components=country:IN&key=${googleApiKey}`);
    const data1 = response1;
    if (data1.data.status !== 'OK') {
      console.error('Error Add Another location:', data1.data.status);
      return null;
    }
    const { lat, lng } = data1.data.results[0].geometry.location;
    if (lat && lng) {
      const response2 = await axios.get(`${API_URL}/api/v1/get-nearby/places-groups?lat=${lat}&lng=${lng}`);
      const data2 = response2.data;
      return data2
    }
    else {
      return null;
    }
  } catch (error) {
    console.log(error.message);
  }
};

async function getDistanceAndTime(nearbyPlaces,origins,placesResponse){
  const destinations = nearbyPlaces.map(place => `${place.geometry.location.lat},${place.geometry.location.lng}`);
  if (!destinations.length) {
    return nearbyPlaces; // No nearby places found
  }
  const distanceMatrixUrl = `https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=${origins.join('|')}&destinations=${destinations.join('|')}&key=${googleApiKey}`;   
  const distanceMatrixResponse = await axios.get(distanceMatrixUrl);
  if (distanceMatrixResponse.data.status !== 'OK') {
    console.error('Error fetching distance matrix:', distanceMatrixResponse.data.error_message);
    return nearbyPlaces; // Return places without distances/times
  }
  const distanceMatrix = distanceMatrixResponse.data.rows[0].elements;
  // Add distance and time information to nearby places
  nearbyPlaces.forEach((place, index) => {
    place.distance = distanceMatrix[index].distance.text;
    place.time = distanceMatrix[index].duration.text;
  });
  return formattedAddress(placesResponse.data.results);
}

function formattedAddress(placesResponse){
  const nearbyPlacesRes = placesResponse.map(place => ({
    name: place.name,
    location: place.geometry.location,  
    place_id: place.place_id,
    distance: place.distance,  
    time: place.time
  }));
  return nearbyPlacesRes;
}

// module.exports = { getNearbyPlaces };
