// utils/createResponse.js
const ResponseModel = require('../models/responseModel');

const createResponse = (data, success=true, httpStatusCode=200, message="40032", errorFields=[], pageNumber=1, pageSize=10) => {
    const totalRecord = data?.length ?? 2;
    const totalPages = Math.ceil(totalRecord / pageSize);
    return new ResponseModel(data, success, httpStatusCode, message, errorFields, pageNumber, pageSize, totalPages, totalRecord);
};

module.exports = createResponse;
